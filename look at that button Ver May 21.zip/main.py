import pygame
from datetime import date
import time
import random
from button import Button
from door import Door
from safe import Safe
from key import Key
from correctkey import CorrectKey

black = pygame.image.load("BIG BLACK RECT.png")
black_x = -1000
black_y = 0

coord_list = [(58,167), (203,167), (337,167), (58,406), (203,406), (337,406), (58,649), (203, 649), (337,649)]
key_list = ['key1', 'key2', 'key3','key4','key5','key6','key7','key8','correct_key']
def arrange_keys():
    random.shuffle(key_list)
    count = 0
    for x in key_list:
        if x == 'correct_key':
            break
        else:
            count+=1

    correct_key_coord = coord_list[count]
    correct_key = CorrectKey(correct_key_coord)

# set up pygame modules
pygame.init()
pygame.font.init()
title_screen = pygame.image.load("title screen.png")
my_font = pygame.font.SysFont('Times New Roman', 50)
other_font = pygame.font.SysFont('Arial', 20)
pygame.display.set_caption("DON'T PRESS THE BUTTON")
size = (1000, 800)
screen = pygame.display.set_mode(size)
bg = pygame.image.load("background.png")
run = True
button = Button(440, 400)
d = Door(70,195, 'door.png')
backdoor = Door(70,195,'green rect.png')
r = 245
g = 240
b = 240
button_pressed = 0
display_button_pressed = my_font.render(str(button_pressed), True, (0,0,0))
start_time = time.time()
timer_run = True
this = 0
secret_ending = False
display_instruct = other_font.render(" ", True, (0,0,0))
instruct = True
that = 0
slide_in = False
start = False
display_timer = my_font.render(' ', True, (0, 0, 0))
display_this = my_font.render('Click to start', True, (0,0,0))
timer = 0
display_achievement = other_font.render(' ', True, (0,0,0))
insert = True
safe = Safe(-300,-300)
# -------- Main Program Loop -----------
while run:
   current_time = time.time()
   if start == True:
       secs = current_time - start_time
       timer = 40 - round(secs)
       if timer <= 0:
           display_timer = my_font.render(' ', True, (0, 0, 0))
           timer_run = False
       else:
           if black_x >= 0:
               display_timer = my_font.render(' ', True, (0,0,0))
           else:
                display_timer = my_font.render(str(timer), True, (0, 0, 0))

   # --- Main event loop
   for event in pygame.event.get():  # User did something

       position = pygame.mouse.get_pos() #temporary code to get mouse coordinates
       mouse_x = position[0] - 40
       mouse_y = position[1] - 20
       mouse_pos = other_font.render(str(position), True, (0,0,0))

       if event.type == pygame.QUIT:  # If user clicked close
           run = False
       if event.type == pygame.MOUSEBUTTONUP:
           start = True
           if button.rect.collidepoint(event.pos):
             if timer_run == True:
                 if button.image_num == 0:
                    button.button_pressed()
                 elif button.image_num == 1:
                    button.button_unpressed()
                    button_pressed +=1
             display_button_pressed = my_font.render(str(button_pressed), True, (0, 0, 0))

           if backdoor.rect.collidepoint(event.pos):
             if secret_ending == True:
                 slide_in = True

   if start == True:
       if black_x == 0:
           d.move_left(1000)
           backdoor.move_left(1000)
           button.move(-300, -100)
           bg = pygame.image.load("minigame-bg.png")  # placeholder until I come up with an actual background
           instruct = False
           display_instruct = other_font.render(" ", True, (0, 0, 0))
           display_button_pressed = my_font.render(' ', True, (0, 0, 0))
           display_timer = my_font.render(' ', True, (0, 0, 0))
           safe.move(650,450)
       if black_x >= 0:
           display_achievement = other_font.render(' ', True, (0,0,0))
       if slide_in == True:
           if that <= 2000:
               black_x += 5
           else:
               slide_in = False

       if timer_run == False and button_pressed == 0 and button.image_num == 1:
           button_pressed += 1
           button.button_unpressed()
           display_button_pressed = my_font.render(str(button_pressed), True, (0, 0, 0))

       if timer == 20 and button_pressed == 38: #secret ending
           print('SECRET ENDING')
           secret_ending = True

       if secret_ending == True:
           achieved = False
           if this <= 50:
               d.move_left(5)
               this += 1

           if this >= 50 and instruct == True:
               display_instruct = other_font.render("Click here ^", True, (0,0,0))

           f = open('achievements', 'r')
           data = f.readlines()
           for x in data:
               if x == "door opened":
                   achieved = True
           if achieved == False:
               f = open("achievements", "a")
               if insert == True:
                   f.write("door opened")
                   insert = False
               if black_x >= 0:
                   display_achievement = other_font.render(' ', True, (0,0,0))
               else:
                   display_achievement = other_font.render("You opened the door", True, (0,0,0))

       if timer_run == False and secret_ending == False:
           achieved = False
           if button_pressed == 0:
               print("GOOD ENDING") #good ending
               f = open('achievements' , 'r')
               data = f.readlines()
               for x in data:
                   if x == "good ending":
                       achieved = True
               if achieved == False:
                   f = open("achievements", "a")
                   f.write("good ending")
                   display_achievement = other_font.render("you unlocked the Good Ending", True, (0, 0, 0))


           else:
               print('BAD ENDING') #bad ending
               f = open('achievements' , 'r')
               data = f.readlines()
               for x in data:
                   if x == "bad ending":
                       achieved = True
               if achieved == False:
                   f = open("achievements", "a")
                   f.write("bad ending")
                   display_achievement = other_font.render("you unlocked the Bad Ending", True, (0, 0, 0))

   screen.fill((r,g,b))
   screen.blit(bg, (0,0))
   screen.blit(button.image, button.rect)
   screen.blit(display_button_pressed, (500,0))
   screen.blit(display_timer, (0,0))
   screen.blit(backdoor.image, backdoor.rect)
   screen.blit(display_instruct, (70,630))
   screen.blit(d.image, d.rect)
   screen.blit(display_achievement, (0, 700))
   screen.blit(safe.image, safe.rect)
   screen.blit(mouse_pos, (mouse_x, mouse_y))
   if start == False:
        screen.blit(title_screen, (150,200))
        screen.blit(display_this, (150,400))
   screen.blit(black, (black_x, black_y))
   pygame.display.update()


