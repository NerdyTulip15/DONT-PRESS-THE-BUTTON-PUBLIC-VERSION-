import pygame
from datetime import date
import time
from random import randint
from button import Button
from door import Door

black = pygame.image.load("BIG BLACK RECT.png")
black_x = -1000
black_y = 0

# set up pygame modules
pygame.init()
pygame.font.init()
my_font = pygame.font.SysFont('Times New Roman', 50)
other_font = pygame.font.SysFont('Arial', 20)
pygame.display.set_caption("DON'T PRESS THE BUTTON")
size = (1000, 800)
screen = pygame.display.set_mode(size)
bg = pygame.image.load("background.png")
run = True
button = Button(440, 400)
d = Door(70,195, 'door.png')
backdoor = Door(70,195,'green rect.png')
r = 245
g = 240
b = 240
button_pressed = 0
display_button_pressed = my_font.render(str(button_pressed), True, (0,0,0))
start_time = time.time()
timer_run = True
this = 0
secret_ending = False
display_instruct = other_font.render(" ", True, (0,0,0))
instruct = True
that = 0
slide_in = False
# -------- Main Program Loop -----------
while run:

   current_time = time.time()
   secs = current_time - start_time
   timer = 40 - round(secs)
   if timer <= 0:
       display_timer = my_font.render(' ', True, (0, 0, 0))
       timer_run = False
   else:
       display_timer = my_font.render(str(timer), True, (0, 0, 0))

   # --- Main event loop
   for event in pygame.event.get():  # User did something
       if event.type == pygame.QUIT:  # If user clicked close
           run = False
       if event.type == pygame.MOUSEBUTTONUP:
         if button.rect.collidepoint(event.pos):
             if timer_run == True:
                 if button.image_num == 0:
                    button.button_pressed()
                 elif button.image_num == 1:
                    button.button_unpressed()
                    button_pressed +=1
             display_button_pressed = my_font.render(str(button_pressed), True, (0, 0, 0))

         if backdoor.rect.collidepoint(event.pos):
             if secret_ending == True:
                 slide_in = True

   if black_x == 0:
       d.move_left(1000)
       backdoor.move_left(1000)
       button.move(-300, -100)
       bg = pygame.image.load("green rect.png")  # placeholder until I come up with an actual background
       instruct = False
       display_instruct = other_font.render(" ", True, (0, 0, 0))
       display_button_pressed = my_font.render(' ', True, (0, 0, 0))
       display_timer = my_font.render(' ', True, (0, 0, 0))
   if slide_in == True:
       if that <= 2000:
           black_x += 5
           print(black_x)
       else:
           slide_in = False

   if timer_run == False and button_pressed == 0 and button.image_num == 1:
       button_pressed += 1
       button.button_unpressed()
       display_button_pressed = my_font.render(str(button_pressed), True, (0, 0, 0))

   if timer == 20 and button_pressed == 38: #secret ending
       print('SECRET ENDING')
       secret_ending = True

   if secret_ending == True:
       if this <= 50:
           d.move_left(5)
           this += 1

       if this >= 50 and instruct == True:
           display_instruct = other_font.render("Click here ^", True, (0,0,0))


   if timer_run == False and secret_ending == False:
       if button_pressed == 0:
           print("GOOD ENDING") #good ending
       else:
           print('BAD ENDING') #bad ending


   screen.fill((r,g,b))
   screen.blit(bg, (0,0))
   screen.blit(button.image, button.rect)
   screen.blit(display_button_pressed, (500,0))
   screen.blit(display_timer, (0,0))
   screen.blit(backdoor.image, backdoor.rect)
   screen.blit(display_instruct, (70,630))
   screen.blit(d.image, d.rect)
   screen.blit(black, (black_x, black_y))
   pygame.display.update()


