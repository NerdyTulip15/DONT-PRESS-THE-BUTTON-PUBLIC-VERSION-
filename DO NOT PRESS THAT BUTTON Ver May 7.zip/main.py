import pygame
from datetime import date
import time
from random import randint
from button import Button
from door import Door

# set up pygame modules
pygame.init()
pygame.font.init()
my_font = pygame.font.SysFont('Times New Roman', 50)
pygame.display.set_caption("DON'T PRESS THE BUTTON")
size = (1000, 800)
screen = pygame.display.set_mode(size)
bg = pygame.image.load("background.png")
run = True
button = Button(440, 400)
d = Door(70,195, 'door.png')
backdoor = Door(70,195,'green rect.png')
r = 245
g = 240
b = 240
button_pressed = 0
display_button_pressed = my_font.render(str(button_pressed), True, (0,0,0))
start_time = time.time()
timer_run = True
# -------- Main Program Loop -----------
while run:

   current_time = time.time()
   secs = current_time - start_time
   timer = 40 - round(secs)
   if timer <= 0:
       display_timer = my_font.render(' ', True, (0, 0, 0))
       timer_run = False
   else:
       display_timer = my_font.render(str(timer), True, (0, 0, 0))

   # --- Main event loop
   for event in pygame.event.get():  # User did something
       if event.type == pygame.QUIT:  # If user clicked close
           run = False
       if event.type == pygame.MOUSEBUTTONUP:
         if button.rect.collidepoint(event.pos):
             if timer_run == True:
                 if button.image_num == 0:
                    button.button_pressed()
                 elif button.image_num == 1:
                    button.button_unpressed()
                    button_pressed +=1
             display_button_pressed = my_font.render(str(button_pressed), True, (0, 0, 0))

   if timer_run == False and button_pressed == 0 and button.image_num == 1:
       button_pressed += 1
       button.button_unpressed()
       display_button_pressed = my_font.render(str(button_pressed), True, (0, 0, 0))

   if timer == 20 and button_pressed == 38: #secret ending
       print('SECRET ENDING')

   if timer_run == False:
       if button_pressed == 0:
           print("GOOD ENDING") #good ending
       else:
           print('BAD ENDING') #bad ending


   screen.fill((r,g,b))
   screen.blit(bg, (0,0))
   screen.blit(button.image, button.rect)
   screen.blit(display_button_pressed, (500,0))
   screen.blit(display_timer, (0,0))
   screen.blit(backdoor.image, backdoor.rect)
   screen.blit(d.image, d.rect)
   pygame.display.update()


